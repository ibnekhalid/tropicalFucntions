#' Trignomatric fucntion of cos(x)
#'
#'  this is a function used to find cos
#'  @param angle must b in radians
#'  @return value of x
#'  @export
#'  trcos(x) is function name

tricos <- function(x){
  return(cos(x))
}
